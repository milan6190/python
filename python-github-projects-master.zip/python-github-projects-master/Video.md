##Video

1. youtube-dl  
Download videos from youtube.com or other video platforms.  
Project Source: https://github.com/rg3/youtube-dl  
Project Homepage: http://rg3.github.io/youtube-dl/

1. Sick-Beard  
PVR & episode guide that downloads and manages all your TV shows.  
Project Source: https://github.com/midgetspy/Sick-Beard  
Project Homepage: https://code.google.com/p/sickbeard/

1. moviepy   
MoviePy is a Python module for script-based movie editing.  
Project Source: https://github.com/Zulko/moviepy  
Project Homepage: http://zulko.github.io/moviepy/

1. coursera  
Script for downloading Coursera.org videos and naming them.  
Project Source: https://github.com/coursera-dl/coursera  

1. CouchPotatoServer  
CouchPotato is an automatic NZB and torrent downloader.  
Project Source: https://github.com/RuudBurger/CouchPotatoServer  
Project Homepage: https://couchpota.to/

1. xunlei-lixian  
xunlei offline download script.  
Project Source: https://github.com/iambus/xunlei-lixian   

1. you-get   
A YouTube/Youku/Niconico video downloader written in Python 3.   
Project Source: https://github.com/soimort/you-get   
Project Homepage: http://www.soimort.org/you-get/   

1. SickRage   
SickRage - Searches TheTVDB and TVRage for shows.    
Project Source: https://github.com/echel0n/SickRage    