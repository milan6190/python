##Game

1. Minecraft  
Simple Minecraft-inspired demo written in Python and Pyglet.  
Project Source: https://github.com/fogleman/Minecraft  
Online Demo Address: http://www.youtube.com/watch?v=kC3lwK631X8 

1. Mario-Level-1  
The first level of Super Mario Bros made with Python and Pygame.  
Project Source: https://github.com/justinmeister/Mario-Level-1  
Online Video Address: http://www.youtube.com/watch?v=HBbzYKMfx5Y  