##Package Manager 

1. pip  
A tool for installing Python packages.  
Project Source: https://github.com/pypa/pip  
Project Documentation: https://pip.pypa.io/en/latest/ 

1. sublime_package_control  
A Sublime Text 2/3 package manager for easily discovering, installing, upgrading and removing packages.  
Project Source: https://github.com/wbond/sublime_package_control  
Project Homepage: https://sublime.wbond.net/  
 
1. package_control_channel  
Default channel file for Package Control.  
Project Source: https://github.com/wbond/package_control_channel  
Project Homepage: https://sublime.wbond.net/docs/developers 


 