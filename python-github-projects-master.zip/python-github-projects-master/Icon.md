##Icon 

1. Iconic  
A minimal set of icons in raster, vector and font formats  
Project Source: https://github.com/somerandomdude/Iconic  
Project Homepage: https://useiconic.com/open/

1. font-awesome-to-png   
Exports Font Awesome icons as PNG images   
Project Source:  https://github.com/odyniec/font-awesome-to-png      
Project Homepage: http://fortawesome.github.io/Font-Awesome/  
 