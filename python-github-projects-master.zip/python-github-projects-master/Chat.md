##Chat

1. quietnet  
Simple chat program using near ultrasonic frequencies. Works without Wifi or Bluetooth and won't show up in a pcap.  
Project Source: https://github.com/Katee/quietnet