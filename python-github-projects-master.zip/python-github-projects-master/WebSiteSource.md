##Web Site Source

1. reddit  
The code that powers reddit.com.  
Project Source: https://github.com/reddit/reddit  
Project Homepage: http://www.reddit.com/r/redditdev

1. readthedocs.org
The source code to readthedocs.org.  
Project Source: https://github.com/rtfd/readthedocs.org  
Project Homepage: https://readthedocs.org/

1. pinry  
The open-source core of Pinry, a tiling image board system for people who want to save, tag, and share images, videos and webpages in an easy to skim through format.  
Project Source: https://github.com/pinry/pinry   
Project Homepage: http://getpinry.com/  

1. class2go  
Class2Go is Stanford's internal open-source platform for on-line education.  
Project source: https://github.com/Stanford-Online/class2go  
Project Homepage: http://class2go.stanford.edu/

1. pythondotorg   
The new python.org.  
Project Source: https://github.com/python/pythondotorg 

1. zamboni   
The backend of the Firefox Marketplace.    
Project Source: https://github.com/mozilla/zamboni    
Project Documentation: http://zamboni.readthedocs.org/en/latest/  
