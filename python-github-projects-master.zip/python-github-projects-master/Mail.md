##Mail  

1. Mailpile  
Mailpile is a modern, fast web-mail client with user-friendly encryption and privacy features.  
Project Source: https://github.com/pagekite/Mailpile  
Project Homepage: https://www.mailpile.is/

1. kite  
Kite is a webmail designed to look a lot like gmail and to be easily deployable on a single server.  
Project Source: https://github.com/khamidou/kite  
Project Homepage: http://kiteapp.io/  

1. inbox.py   
Python SMTP Server for Humans.  
Project Source: https://github.com/kennethreitz/inbox.py  
Project Documentation: https://pypi.python.org/pypi/inbox/
  
1. gmail  
A Pythonic interface to Google's GMail, with all the tools you'll need.   
Project Source: https://github.com/charlierguo/gmail  

1. gmvault  
Gmvault is a tool for backing up your gmail account and never lose email correspondence.   
Project Source: https://github.com/gaubert/gmvault  
Project Website: http://gmvault.org/

1. imbox  
Python library for reading IMAP mailboxes and converting email content to machine readable data.   
Project Source: https://github.com/martinrusev/imbox. 

1. mailin   
Artisanal inbound emails for every web app.   
Project Source: https://github.com/Flolagale/mailin    
Project Homepage: http://mailin.io/   

1. envelopes   
Mailing for human beings.    
Project Source: https://github.com/tomekwojcik/envelopes    
Project Documentation: http://tomekwojcik.github.io/envelopes/

1. mailur   
Webmail client with Gmail-like conversations.   
Project Source: https://github.com/naspeh/mailur     
Project Homepage: http://pusto.org/en/mailr/      

1. lamson    
Pythonic SMTP Application Server.    
Project Source: https://github.com/zedshaw/lamson    
Project Homepage: http://lamsonproject.org/    

