##Algorithm

1. algorithms  
module of algorithms for Python.   
Project Source: https://github.com/nryoung/algorithms
 
   
  
